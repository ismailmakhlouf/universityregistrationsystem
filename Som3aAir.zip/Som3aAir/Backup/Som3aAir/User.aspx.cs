﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Som3aAir
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie myCookie = new HttpCookie("UserCookie");
            myCookie = Request.Cookies["UserCookie"];

            //// Read the cookie information and display it.
            //if (myCookie != null)
            //    Response.Write("<p>" + myCookie.Name + "<p>" + myCookie.Value);
            //else
            //    Response.Write("not found");
        }

        protected void btnViewAccount_Click(object sender, EventArgs e)
        {
            Response.Redirect("displayAccount.aspx");
        }
    }
}