﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Text.RegularExpressions;

namespace Som3aAir
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {

            bool noerrors = true;
            bool hasimage = false;
            txtErrMsg.InnerText = "";
            string fullpath = "";
            string savestring = "";

            // Firstname validation
            string fnameregex = @"([A-Z][a-z]*)|([A-Z][a-z][ \t] [A-Z][a-z]*)";

            try
            {
                if (((Regex.IsMatch(txtFirstName.Text, fnameregex)) == false) || (txtFirstName.Text == ""))
                {
                    txtErrMsg.InnerText += "Error! Please enter a first name in Title Case (1-2 words only) \r";
                    noerrors = false;
                }
                else
                {
                    //txtErrMsg.InnerText += "First name is valid \n";
                }
            }
            catch (Exception ex)
            {
                // Most likely cause is a syntax error in the regular expression
                txtErrMsg.InnerText += "Regex.IsMatch() threw an exception:\r\n" + ex.Message;
            }

            // Firstname validation
            string lnameregex = @"([A-Z][a-z]*)|([A-Z][a-z][ \t] [A-Z][a-z]*)";

            try
            {
                if (((Regex.IsMatch(txtLastName.Text, lnameregex)) == false) || (txtLastName.Text == ""))
                {
                    txtErrMsg.InnerText += "Error! Please enter a last name in Title Case (1-2 words only) \r";
                    noerrors = false;
                }
                else
                {
                    //txtErrMsg.InnerText += "First name is valid \n";
                }
            }
            catch (Exception ex)
            {
                // Most likely cause is a syntax error in the regular expression
                txtErrMsg.InnerText += "Regex.IsMatch() threw an exception:\r\n" + ex.Message;
            }

            // Email Validation

            string emailregex = @"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,6}$";

            try
            {
                if (((Regex.IsMatch(txtEmail.Text, emailregex, RegexOptions.IgnoreCase)) == false) || (txtEmail.Text == ""))
                {
                    txtErrMsg.InnerText += "Error! Please enter a valid email address\r";
                    noerrors = false;
                }
                else
                {
                    //txtErrMsg.InnerText += "Email address is valid\n";
                }
            }
            catch (Exception ex)
            {
                // Most likely cause is a syntax error in the regular expression
                txtErrMsg.InnerText = "Regex.IsMatch() threw an exception:\r\n" + ex.Message;
            }

            // Student ID validation
            string sidregex = @"[9][0-9][0-9]-[0-1][0-9]-([0-9]{4})";

            try
            {
                if (((Regex.IsMatch(txtStudentId.Text, sidregex)) == false) || (txtStudentId.Text == ""))
                {
                    txtErrMsg.InnerText += "Error! Please enter a valid ID (XXX-YY-SSSS) \r";
                    noerrors = false;
                }
                else
                {
                    //txtErrMsg.InnerText += "Student ID is valid \n";
                }
            }
            catch (Exception ex)
            {
                // Most likely cause is a syntax error in the regular expression
                txtErrMsg.InnerText += "Regex.IsMatch() threw an exception:\r\n" + ex.Message;
            }

            // Password Validation
            string passwordregex = @"[a-zA-Z0-9]{8,15}";
            try
            {
                if (((Regex.IsMatch(txtPassword.Text, passwordregex)) == false) || (txtPassword.Text == ""))
                {
                    txtErrMsg.InnerText += "Error! Please enter a password between 8 and 15 characters (no whitespace) \r";
                    noerrors = false;
                }
                else
                {
                    //txtErrMsg.InnerText += "Password is valid \n";
                }
            }
            catch (Exception ex)
            {
                // Most likely cause is a syntax error in the regular expression
                txtErrMsg.InnerText += "Regex.IsMatch() threw an exception:\r\n" + ex.Message;
            }

            if (txtPassword.Text != txtConfirmPassword.Text)
            {
                txtErrMsg.InnerText += "Error! Passwords do not match\n";
                noerrors = false;
            }

            //if (txtPassword.Text == "")
            //{
            //    txtErrMsg.InnerText += "Error! Please enter a valid password between 8 and 15 characters\n";
            //    noerrors = false;
            //}

            //// Converting image into byte array for upload

            ////byte[] img = new byte[1];

            ////if (btnChooseFile.HasFile)
            ////{
            ////    try
            ////    {
            ////        img = new byte[btnChooseFile.PostedFile.ContentLength - 1];
            ////        img = btnChooseFile.FileBytes;
            ////        hasimage = true;
            ////    }
            ////    catch (Exception ex)
            ////    {
            ////        txtErrMsg.InnerText += "Error! Failed to upload image\n";
            ////    }
            ////}

            //// Displays a SaveFileDialog so the user can save the Image
            //// assigned to Button2.
            //SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            //saveFileDialog1.Filter = "JPeg Image|*.jpg|Bitmap Image|*.bmp|Gif Image|*.gif|Png Image|*.png";
            //saveFileDialog1.Title = "Save an Image File";
            //saveFileDialog1.ShowDialog();
            

            //// If the file name is not an empty string open it for saving.
            //if (saveFileDialog1.FileName != "")
            //{
                
                
            //    hasimage = true;
            //    //Saves the Image via a FileStream created by the OpenFile method.
            //    System.IO.FileStream fs =
            //       (System.IO.FileStream)saveFileDialog1.OpenFile();
            //    // Saves the Image in the appropriate ImageFormat based upon the
            //    // File type selected in the dialog box.
            //    // NOTE that the FilterIndex property is one-based.
            //    //switch (saveFileDialog1.FilterIndex)
            //    //{
            //    //    case 1:
            //    //        btnChooseFile.SaveAs(
            //    //        this.btnChooseFile.Image.Save(fs,
            //    //           System.Drawing.Imaging.ImageFormat.Jpeg);
            //    //        break;

            //    //    case 2:
            //    //        this.button2.Image.Save(fs,
            //    //           System.Drawing.Imaging.ImageFormat.Bmp);
            //    //        break;

            //    //    case 3:
            //    //        this.button2.Image.Save(fs,
            //    //           System.Drawing.Imaging.ImageFormat.Gif);
            //    //        break;
            //    //}

               

            //    //fs.Close();
            //}

            
            savestring = "Images\\" + txtStudentId.Text + ".jpg";
            fullpath = Server.MapPath(savestring);
            //string path = Directory.GetCurrentDirectory();

            try
            {
                btnChooseFile.SaveAs(fullpath);
                hasimage = true;
            }

            catch (Exception ex)
            {
                txtErrMsg.InnerText += "Error! Failed to upload image\n";
            }


            if (noerrors == true)
            {
                try
                {
                    SqlConnection conn = new SqlConnection();
                    conn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|StudentDB.mdf;Integrated Security=True;User Instance=True";

                    SqlConnection connimg = conn;

                    string strSelect = "INSERT INTO Student "
                        + " VALUES ('" + txtFirstName.Text + "' , "
                        + "'" + txtLastName.Text + "' , "
                        + "'" + rblGender.SelectedValue + "' , "
                        + "'" + lstMajor.SelectedValue + "' , "
                        + "'" + txtEmail.Text + "' ,"
                        + "'" + txtStudentId.Text + "' ,"
                        + "'" + txtPassword.Text + "')";
                    // + " ; INSERT INTO StudentPictures "
                    //+ " VALUES ('" + txtStudentId.Text + "' , "
                    //+ btnChooseFile.FileContent + ")";

                    SqlCommand cmdSelect = new SqlCommand(strSelect, conn);

                    if (hasimage == true)
                    {
                        string strSelectimg = "INSERT INTO StudentPictures "
                           + " VALUES ('" + txtStudentId.Text + "' , "
                           + "'" + savestring + "')";

                        SqlCommand cmdSelectimg = new SqlCommand(strSelectimg, connimg);

                        conn.Open();
                        cmdSelect.ExecuteNonQuery();
                        cmdSelectimg.ExecuteNonQuery();
                        conn.Close();
                    }


                    else
                    {
                        conn.Open();
                        cmdSelect.ExecuteNonQuery();
                        conn.Close();
                    }

                    // Creating Cookie

                    HttpCookie myCookie = new HttpCookie("UserCookie");
                    DateTime now = DateTime.Now;

                    // Set the cookie value.
                    myCookie.Value = txtStudentId.Text;
                    // Set the cookie expiration date.
                    myCookie.Expires = now.AddMinutes(900);

                    // Add the cookie.
                    Response.Cookies.Add(myCookie);

                    Response.Write("<p> The cookie has been written.");
                }
                catch (SqlException ex)
                {
                    if (ex.Number.Equals(2627))
                    {
                        txtErrMsg.InnerText += "Error! Username already exists\n";
                    }
                }

                txtErrMsg.InnerText = "Your account has successfully been created";
                Response.Redirect("User.aspx");
            }

        }

        //protected void btnChooseFile_Click(object sender, EventArgs e)
        //{
        //    // http://techtoggle.com/2009/09/how-to-store-and-retrieve-images-in-sql-server-through-visual-studio-c/


        //    string imagename;

        //    try
        //    {

        //        FileDialog fldlg = new OpenFileDialog();

        //        fldlg.InitialDirectory = @"C:\";

        //        fldlg.Filter = "Image File (*.jpg;*.bmp;*.gif;*.png)|*.jpg;*.bmp;*.gif;*.png";

        //        if (fldlg.ShowDialog() == DialogResult.OK)
        //        {

        //            imagename = fldlg.FileName;

        //            Bitmap newimgbmp = new Bitmap(imagename);

        //            PictureBoxSizeMode picture = PictureBoxSizeMode.StretchImage;

        //            System.Drawing.Image newimg = (System.Drawing.Image)newimgbmp;

        //        }

        //        fldlg = null;

        //    }

        //    catch (System.ArgumentException ae)
        //    {

        //        imagename = " ";

        //        MessageBox.Show(ae.Message.ToString());

        //    }

        //    catch (Exception ex)
        //    {

        //        MessageBox.Show(ex.Message.ToString());


        //    }
        //}
    }
}