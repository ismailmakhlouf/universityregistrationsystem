﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Som3aAir
{
    public partial class displayAccount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //SqlConnection conn = new SqlConnection();
            //conn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|StudentDB.mdf;Integrated Security=True;User Instance=True";

            ////SqlConnection conncurr = conn;

            ////string strSelect = "SELECT * FROM Student "
            ////    + " WHERE StudentId = " + txtUsername.Text + " AND "
            ////    + " Password = '" + txtPassword.Text + "'";

            //string strSelect = "SELECT * FROM CurrentUser";

            //SqlCommand cmdSelect = new SqlCommand(strSelect, conn);

            //SqlDataReader reader;

            ////try
            ////{
            //conn.Open();
            //reader = cmdSelect.ExecuteReader();
            ////string userid = reader.GetValue(1).ToString();
            //conn.Close();
            //txtErrMsg.InnerText = userid;

            HttpCookie myCookie = new HttpCookie("UserCookie");
            myCookie = Request.Cookies["UserCookie"];

            // Read the cookie information and display it.
            //if (myCookie != null)
            //    Response.Write("<p>" + myCookie.Name + "<p>" + myCookie.Value);
            //else
            //    Response.Write("not found");

            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|StudentDB.mdf;Integrated Security=True;User Instance=True";


            string strSelect = "SELECT * FROM Student "
                + "WHERE StudentId = '" + myCookie.Value + "'";

            SqlCommand cmdSelect = new SqlCommand(strSelect, conn);

            SqlDataReader reader;

            conn.Open();

            reader = cmdSelect.ExecuteReader();


            while (reader.Read())
            {
                // get the results of each column
                txtFirstName.Text = (string)reader["Firstname"];
                txtLastName.Text = (string)reader["Lastname"];
                txtEmail.Text = (string)reader["Email"];
                txtGender.Text = (string)reader["Gender"];
                txtMajor.Text = (string)reader["Major"];
                txtStudentId.Text = (string)reader["StudentId"];
                txtPassword.Text = (string)reader["Password"];
            }

            reader.Close();
            conn.Close();

            //SqlConnection conn = new SqlConnection();
            //conn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|StudentDB.mdf;Integrated Security=True;User Instance=True";


            //strSelect = "SELECT * FROM StudentPictures "
            //    + "WHERE StudentId = '" + myCookie.Value + "'";

            //cmdSelect = new SqlCommand(strSelect, conn);

            //conn.Open();

            //reader = cmdSelect.ExecuteReader();


            //while (reader.Read())
            //{
            //    //imgProfilePic.Src = "data:image/png;base64," + Convert.ToBase64String((byte[])reader["ProfilePicture"]);
            //    //imgProfilePic.ImageUrl = (string)reader["ProfilePictures"];
                
            //}

            //reader.Close();
            //conn.Close();

            imgProfilePic.ImageUrl = "Images\\" + txtStudentId.Text + ".jpg";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("home.htm");
            HttpCookie myCookie = new HttpCookie("UserCookie");
            DateTime now = DateTime.Now;
            myCookie.Expires = now;

        }
    }
}